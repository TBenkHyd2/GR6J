function [x] = HU2(x,C,NH,NPX);
% Function calculates time delay
%-ORDONNEE HYDROGRAMME UNITAIRE2 : Rapide Matlab code By T. Benkaci
%  x(NPX + NH + k)  Ordinates of UH2 (calculated in Subroutine UH2)
% According to GR6J Model Fortran (CEMAGREF)

for k = 1:2*NH,
    x(NPX + NH + k) = SS2(k,x(4))-SS2(k-1,x(4));
end;