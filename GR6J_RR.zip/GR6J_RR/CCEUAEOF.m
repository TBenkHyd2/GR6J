%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [S,Sf,icall]=CCEUAEOF(s,sf,bl,bu,icall)

[nps,nopt]=size(s);
n = nps;
alpha = 1.0; % reflection coefficient.
beta = 0.5;% contraction coefficient.

% Assign the best and worst points:
sb=s(1,:); fb=sf(1);
sN=s(n-1,:); fN=sf(n-1);
sw=s(n,:); fw=sf(n);

% Compute the centroid of the simplex excluding the worst point:
ce=mean(s(1:n-1,:));

% Attempt a reflection point
snew = ce + alpha*(ce-sw);
snew(snew>bu)=2*bu(snew>bu)-snew(snew>bu) ;
snew(snew<bl)=2*bl(snew<bl)-snew(snew<bl);
snew(snew>bu)=bu(snew>bu);
snew(snew<bl)=bl(snew<bl);

fnew = functn(snew);
icall = icall + 1;

if fnew < fN;
    if fnew < fb
        snew1 = snew + alpha*(snew-ce);
        snew1(snew1>bu)=2*bu(snew1>bu)-snew1(snew1>bu) ;
        snew1(snew1<bl)=2*bl(snew1<bl)-snew(snew1<bl);
        snew1(snew1>bu)=bu(snew1>bu);
        snew1(snew1<bl)=bl(snew1<bl);
        
        fnew1 = functn(snew1);
        icall = icall + 1;
        if fnew1 < fnew
            fnew=fnew1;
            snew=snew1;
        end
    end
else
    if fnew < fw
        snew1 = ce + beta*(snew-ce);
        fnew1 = functn(snew1);
        icall = icall + 1;
        if fnew1 < fnew
            fnew=fnew1;
            snew=snew1;
        end
    else
        snew = sw + beta*(ce-sw);
        fnew = functn(snew);
        icall = icall + 1;
        if fnew > fw
            sig=cov(s);
            Dia=diag(sig);
            sig=diag((Dia+mean(Dia))*2);
            snew=mvnrnd(ce,sig,1);
            snew(snew>bu)=2*bu(snew>bu)-snew(snew>bu) ;
            snew(snew<bl)=2*bl(snew<bl)-snew(snew<bl);
            snew(snew>bu)=bu(snew>bu);
            snew(snew<bl)=bl(snew<bl);
            fnew = functn(snew);
            icall = icall + 1;
        end
    end
end;

S=s;
Sf=sf;
S(n,:)=snew;
Sf(n)=fnew;

return;


