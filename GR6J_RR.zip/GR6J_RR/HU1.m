function [x] = HU1(x,C,NH,NPX);
%-ORDONNEE HYDROGRAMME UNITAIRE1 : HYDROGRAMME UNITAIRE LENT Matlab code By T. Benkaci
%x(NPX + k)  Ordinates of UH1 (calculated in Subroutine UH1)
% According to GR6J Model Fortran (CEMAGREF)
for k = 1:NH,
    x(NPX + k) = SS1(k,x(4))- SS1(k-1,x(4));
end;