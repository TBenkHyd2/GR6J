% Function of Production (GR6J Model)  By T.Benkaci (According Fortran GR6J)
function [V,PR,S] = Prod_GR6J(S,x,V,PR,P,E);
%Reservoir sol
if P > E, 
  ES=0;
 WS=(P-E)/x(1);
 if(WS>13);WS=13;end;
	  Sr = V(1)/x(1);
      PS=x(1)*(1.-Sr*Sr)*tanh(WS)/(1.+Sr*tanh(WS));
%PS=(x(1)*(1-(V(1)/x(1))^2)*tanh(WS)/(1+(V(1)/x(1))*tanh(WS)));
PR=(P-E)-PS; 
V(1)=V(1)+PS;

else
    PS=0;
    PR=0;
WS=(E-P)/x(1);
     if(WS>13);WS=13;end;
ES=V(1)*(2-(V(1)/x(1)))*tanh(WS)/(1+(1-(V(1)/x(1)))*tanh(WS));  
V(1)=V(1)-ES;
end;

if V(1) <= 0.0, V(1) = 0; end
Sr=V(1)/x(1);
Sr=Sr*Sr;
Sr=Sr*Sr;
PERC=V(1)*(1.-1./sqrt(sqrt(1.+Sr/25.62890625)));  
%25.62890625 instead of: (9/4)^4

V(1)=V(1)-PERC;

PR=PR+PERC;


