function [Snew,Sfnew,icall]=GauSamp(S,Sf,bl,bu,icall)
%subroutine for restoring the population using multinormal distribution
    
    [N,D]=size(S);
    Smean=mean(S);
    Ssig=cov(S);
    Srand=2*mvnrnd(zeros(1,D),Ssig,N)+repmat(Smean,N,1);

    %Move points that are outside bounds back to the feasible spac
    for i=1:N
        t=Srand(i,:);
        R=rand(1,D);
        Diff=bu-bl;
        idxx=t>bu;
        t(idxx)=bl(idxx)+R(idxx).*Diff(idxx);
        idxx=t<bl;
        t(idxx)=bl(idxx)+R(idxx).*Diff(idxx);
        Srand(i,:)=t;
    end
    
    Sfrand=zeros(1,N);
    for k=1:N
        Sfrand(k)= Model(Srand(k,:));
        icall = icall + 1;
    end

    Stotal=[S; Srand];
    Sftotal=[Sf Sfrand];
    [Sftotal,idx]=sort(Sftotal); Stotal=Stotal(idx,:);
    Snew=Stotal(1:N,:);
    Sfnew=Sftotal(1:N);
return
